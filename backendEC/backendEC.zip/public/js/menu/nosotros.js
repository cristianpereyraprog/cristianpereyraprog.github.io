function initNosotros() {
    console.warn('initNosotros()')
}