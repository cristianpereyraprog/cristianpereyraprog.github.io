function initContacto() {
    console.warn('initContacto()')
}